grid_size = 128; %56
%F = fiberInit_QZ(grid_size,plot_distance);% 3.5 for OM3 fiber
show_Plots = 1;
current_path = pwd;
% disp(['current path：', current_path]);
save_folder = fullfile(current_path, 'mmf_data');

%% Fiber Parameters
F.NA = 0.2;
F.r_core = 25; % 12.5; %um
F.wavelength = 1.568; % um
% F.n_core = 1.4585;
F.n_core = 1.45; %from DP 
F.n_cladding = sqrt(F.n_core^2-F.NA^2);    % sqrt(n_core^2-NA^2)

addpath(genpath('mm_fibre_sim'));

% Plot Area
% F.r_plot_max = F.plot_scale*F.r_core;    %1.3 warum berhaupt?
% Calc Fiber
% [F.modeSolver,F.modes,F.n_modes, F.beta_sorted_indices,F.mode_betas] = calc_Modes(F, grid_size, show_Plots);  % Modes for SLM

%% generate different datasets
p_d = 1.05:0.05:1.4;
num_p_d = size(p_d,2);
for index_pd = 1:num_p_d
    F.plot_scale = p_d(index_pd);
    % F.plot_scale
    % Plot Area
    F.r_plot_max = F.plot_scale*F.r_core; 
    % Calc Fiber
    [F.modeSolver,F.modes,F.n_modes, F.beta_sorted_indices,F.mode_betas] = calc_Modes(F, grid_size, show_Plots);  % Modes for SLM
    modes_field = permute(F.modes, [3, 1, 2]);  % H,W,N -> N,H,W
    
    % normalization

    amp = abs(modes_field);                 % amplitude distribution
    amp_min = min(amp(:));
    amp_max = max(amp(:));
    
    amp_norm = (amp - amp_min) / (amp_max - amp_min);   % normalize to [0,1]

    % phase remains the same
    phase = angle(modes_field);  
    modes_field = amp_norm .* exp(1i * phase);

    size(modes_field)
    % with Plot_distance
    save_name = save_folder + "/mmf_"+ num2str(F.n_modes)+"modes_"+num2str(grid_size)+"_PD_"+num2str(F.plot_scale)+".mat";
    % save_name = '/home/qzhang/Desktop/'+ "/mmf_"+ num2str(F.n_modes)+"modes_"+num2str(grid_size)+"_PD_"+num2str(F.plot_scale)+".mat";
    disp(['保存路径为：', save_name]);
    save(save_name,"modes_field");
    disp('保存完成');
end


