function [modes_field, mode_info, n_modes, core_mask] = ...
    calc_GRIN_modes(r_core, n_core, NA, wavelength, ...
                    grid_size, r_plot_max)
% CALC_GRIN_MODES  
% 解析生成抛物线 GRIN 光纤的 LP 模式场分布
%
% 输入:
%   r_core     - 纤芯半径 (um)
%   n_core     - 纤芯折射率
%   NA         - 数值孔径
%   wavelength - 工作波长 (um)
%   grid_size  - 网格点数
%   r_plot_max - 绘图/计算区域半径 (um)
%
% 输出:
%   modes_field - [grid_size x grid_size x N] 模式场
%   mode_info   - 结构体数组
%   n_modes     - 模式总数


% CALC_GRIN_MODES  
% 解析生成抛物线 GRIN 光纤的 LP 模式场分布（带圆形纤芯mask）
%
% 输出:
%   modes_field - [grid_size x grid_size x N] 模式场（圆外为0）
%   mode_info   - 结构体数组
%   n_modes     - 模式总数
%   core_mask   - [grid_size x grid_size] 逻辑矩阵，纤芯内=true

    %% 光纤参数
    k0 = 2 * pi / wavelength;
    V = k0 * r_core * NA;
    M = floor(V / 2);
    Delta = NA^2 / (2 * n_core^2);
    g = sqrt(2 * Delta) / r_core;
    r0 = 1 / sqrt(k0 * n_core * g);

    fprintf('V = %.2f, M = %d, r0 = %.2f um\n', V, M, r0);
    fprintf('预期模式数: %d\n', M*(M+1)/2);

    %% 建立网格
    x = linspace(-r_plot_max, r_plot_max, grid_size);
    [X, Y] = meshgrid(x, x);
    R = sqrt(X.^2 + Y.^2);
    PHI = atan2(Y, X);
    rho = R / r0;
    rho2 = rho.^2;

    %% ===== 圆形纤芯 mask =====
    core_mask = (R <= r_core);
    fprintf('纤芯内像素: %d / %d (%.1f%%)\n', ...
        sum(core_mask(:)), numel(core_mask), ...
        100 * sum(core_mask(:)) / numel(core_mask));
    %% ===========================

    %% 枚举所有 LP 模式
    N_total = M * (M + 1) / 2;
    modes_field = zeros(grid_size, grid_size, N_total);
    mode_info = struct('l', {}, 'p', {}, ...
                       'orient', {}, 'group', {});
    mode_idx = 0;

    for group = 0:(M - 1)
        % for l = group:-2:0
        % for l = group:-2:0
        for l = mod(group,2):2:group
            p = (group - l) / 2 + 1;

            Lpl = gen_laguerre(p - 1, l, rho2);
            radial = (rho.^l) .* Lpl .* exp(-rho2 / 2);

            if l == 0
                mode_idx = mode_idx + 1;
                field = radial;
                field(~core_mask) = 0;     % ← 圆外清零
                field = field / sqrt(sum(abs(field(:)).^2));
                modes_field(:,:,mode_idx) = field;
                mode_info(mode_idx).l = l;
                mode_info(mode_idx).p = p;
                mode_info(mode_idx).orient = 'none';
                mode_info(mode_idx).group = group;
            else
                % cos
                mode_idx = mode_idx + 1;
                field = radial .* cos(l * PHI);
                field(~core_mask) = 0;     % ← 圆外清零
                field = field / sqrt(sum(abs(field(:)).^2));
                modes_field(:,:,mode_idx) = field;
                mode_info(mode_idx).l = l;
                mode_info(mode_idx).p = p;
                mode_info(mode_idx).orient = 'cos';
                mode_info(mode_idx).group = group;

                % sin
                mode_idx = mode_idx + 1;
                field = radial .* sin(l * PHI);
                field(~core_mask) = 0;     % ← 圆外清零
                field = field / sqrt(sum(abs(field(:)).^2));
                modes_field(:,:,mode_idx) = field;
                mode_info(mode_idx).l = l;
                mode_info(mode_idx).p = p;
                mode_info(mode_idx).orient = 'sin';
                mode_info(mode_idx).group = group;
            end
        end
    end

    n_modes = mode_idx;
    fprintf('实际生成模式数: %d\n', n_modes);

    if n_modes ~= N_total
        warning('模式数不匹配！预期 %d，实际 %d', ...
                N_total, n_modes);
    end

    %% ===== 验证 mask 生效 =====
    test_field = modes_field(:,:,1);
    corners = [test_field(1,1), test_field(1,end), ...
               test_field(end,1), test_field(end,end)];
    fprintf('四个角的值: [%.6f, %.6f, %.6f, %.6f]\n', corners);
    fprintf('应全为 0 → mask 生效: %s\n', ...
        mat2str(all(corners == 0)));
    %% ============================
end


function L = gen_laguerre(n, alpha, x)
    if n == 0
        L = ones(size(x));
    elseif n == 1
        L = 1 + alpha - x;
    else
        Lm1 = 1 + alpha - x;
        Lm2 = ones(size(x));
        for k = 1:(n - 1)
            L = ((2*k + 1 + alpha - x) .* Lm1 ...
                 - (k + alpha) * Lm2) / (k + 1);
            Lm2 = Lm1;
            Lm1 = L;
        end
    end
end
