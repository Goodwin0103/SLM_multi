% 假设你的变量名是 test_complex_gt 和 reconstructed_images
% 维度是 [1000, 1, 128, 128]

num_samples = size(test_complex_gt, 1); % 这里应该是 1000

% 预分配数组，用来保存 1000 张图的 CC 值，加快运行速度
cc_amp_list = zeros(num_samples, 1);
cc_phase_list = zeros(num_samples, 1);

for i = 1:num_samples
    % 1. 提取第 i 张图
    % MATLAB 中提取出的维度可能是 [1, 1, 128, 128]
    % 用 squeeze 函数去掉大小为 1 的维度，使其变成 [128, 128] 的二维矩阵
    img_true = squeeze(test_complex_gt(i, 1, :, :));
    img_pred = squeeze(reconstructed_fields(i, 1, :, :));
    
    % 2. 处理复数：分别提取 振幅(Amplitude) 和 相位(Phase)
    amp_true = abs(img_true);
    amp_pred = abs(img_pred);
    
    phase_true = angle(img_true);
    phase_pred = angle(img_pred);
    
    % 3. 计算振幅的 CC
    % 在 MATLAB 中， A(:) 相当于 Python 的 flatten()，把二维矩阵拉成一维列向量
    % corrcoef 返回的是 2x2 的相关系数矩阵，位置 (1,2) 上的值就是这两个向量的 CC
    R_amp = corrcoef(amp_true(:), amp_pred(:));
    cc_amp_list(i) = R_amp(1, 2);
    
    % 4. 计算相位的 CC
    R_phase = corrcoef(phase_true(:), phase_pred(:));
    cc_phase_list(i) = R_phase(1, 2);
end

% 打印最终结果
fprintf('成功计算了 %d 张图像的 CC。\n', num_samples);
fprintf('振幅平均相关系数 Mean CC (Amplitude): %.4f\n', mean(cc_amp_list));
fprintf('相位平均相关系数 Mean CC (Phase): %.4f\n', mean(cc_phase_list));

% 如果你想画出和你之前发的那种箱线图 (Boxplot) 一样的图，可以直接用 MATLAB 的 boxplot：
% figure;
% boxplot([cc_amp_list, cc_phase_list], 'Labels', {'CC(Amplitude)', 'CC(Phase)'});
% title('Correlation Coefficient Boxplot');
%%
% --- 1. 选择你想查看的图片索引 ---
% 比如查看 1000 张里的第 1 张
img_idx = 17; 

% --- 2. 提取数据并去掉多余维度 ---
% 将 [1000, 1, 128, 128] 中第 img_idx 张提取成 [128, 128]
img_true_complex = squeeze(test_complex_gt(img_idx, 1, :, :));
img_pred_complex = squeeze(reconstructed_fields(img_idx, 1, :, :));

% --- 3. 分离振幅 (Amplitude) 和 相位 (Phase) ---
% 振幅用 abs() 计算
amp_true = abs(img_true_complex);
amp_pred = abs(img_pred_complex);

% 相位用 angle() 计算
phase_true = angle(img_true_complex);
phase_pred = angle(img_pred_complex);

% --- 4. 开始用 subplot 画图 ---
% 创建一个较大的图形窗口
figure('Name', '原始与预测图像对比', 'Position', [100, 100, 800, 700]);

% --- 第一行：振幅对比 (灰度图) ---
% Subplot 1: 原始振幅
subplot(2, 2, 1);
imagesc(amp_true);         % 自动缩放颜色范围显示图像
colormap(gca);     % 振幅通常用灰度显示
colorbar;                  % 显示颜色条
axis image off;            % 保持 1:1 比例，并隐藏坐标轴的数字
title(['原始振幅 (GT) - 第 ', num2str(img_idx), ' 张'], 'FontSize', 12);

% Subplot 2: 预测振幅
subplot(2, 2, 2);
imagesc(amp_pred);
colormap(gca);
colorbar;
axis image off;
title(['预测振幅 (Pred) - 第 ', num2str(img_idx), ' 张'], 'FontSize', 12);

% --- 第二行：相位对比 (彩色图) ---
% Subplot 3: 原始相位
subplot(2, 2, 3);
imagesc(phase_true);
colormap(gca, 'parula');   % 相位包含正负值，用默认的彩色(parula)更容易看出细节
colorbar;
axis image off;
title('原始相位 (GT)', 'FontSize', 12);

% Subplot 4: 预测相位
subplot(2, 2, 4);
imagesc(phase_pred);
colormap(gca, 'parula');
colorbar;
axis image off;
title('预测相位 (Pred)', 'FontSize', 12);
