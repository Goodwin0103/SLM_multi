function F = fiberInit(grid_size, plot_scale, r_core, NA, wavelength)
%FIBERINIT Summary of this function goes here
%   Detailed explanation goes here

show_Plots = false;

%% Fiber Parameters
F.plot_scale = 1.1;
F.NA = 0.1;
F.r_core = 12.5;
F.wavelength = 0.532;

switch nargin
    case 2
        F.plot_scale = plot_scale;
%     case 3
%         F.NA = NA;
%         F.r_core = r_core;
    case 4
        F.NA = NA;
        F.r_core = r_core;
    case 5
        F.NA = NA;
        F.r_core = r_core;
        F.wavelength = wavelength;     % 
    % otherwise
        % F.NA = 0.1; %0.1
        % F.r_core = 12.5; %+/- 1.5m  12.5             % 3, 4, 5, 12.5
        % F.wavelength = 0.532;     % 
        % F.plot_scale = 1.1;
end

F.n_core = 1.4585;
F.n_cladding = sqrt(F.n_core^2-F.NA^2);    % sqrt(n_core^2-NA^2)

addpath(genpath('mm_fibre_sim'));

%% Plot Area
F.r_plot_max = F.plot_scale*F.r_core;    %1.3 warum berhaupt?

%% Check load data
fName = ['Fiber_',...
    num2str(F.r_core*1000),'nm_core_',...
    num2str(F.NA*1000),'m_NA_',...
    num2str(grid_size),'gridSize'];

if isfile([fName,'.mat'])
    load([fName,'.mat'],'F');
else
    %% Calc Fiber
    [F.modeSolver,F.modes,F.n_modes, F.beta_sorted_indices,F.mode_betas] = calc_Modes(F, grid_size, show_Plots);  % Modes for SLM
            
    % Gaussian reference, superposition
    F.modes_ref = (1/sqrt(2)) .* ( F.modes(:,:,1)+F.modes );
    F.modes_half= (1/sqrt(2)) .* F.modes;
    % F.modes_ref  = 0.5*F.modes(:,:,1) + 0.5*F.modes;
    % F.modes_half = 0.5*F.modes;
    max_val = max([ ...
        abs(F.modes), ...
        abs(F.modes_ref), ...
        abs(F.modes_half)],[],'all');

    %% test fourier
%     cut_radius = 2*grid_size/4;
%     F.modesFourier = zeros(2*cut_radius,2*cut_radius,F.n_modes);
% 
%     for i=1:10 %F.n_modes
% %         F.modesFourier(:,:,i) = ...%fftshift( ...
% %             fft2(F.modes(:,:,i)) ...
% %             ...%)...
% %             ;
% 
%         mode_field_fourier = fftshift(...
%             ifft2(...
%                 padarray(...
%                     F.modes(:,:,i),[1500,1500],0,'both'...
%                 )...
%             )...
%         );   
%         dims = size(mode_field_fourier);
%         mode_field_fourier = mode_field_fourier(dims(1)/2-cut_radius+1:dims(1)/2+cut_radius,dims(2)/2-cut_radius+1:dims(2)/2+cut_radius);
%         figure(43);imagesc(abs(mode_field_fourier));    
%         F.modesFourier(:,:,i) = mode_field_fourier;
% %         pause(1);
% %         F.modesFourier(:,:,i) = F.modesFourier(:,:,i) ./ max(max(max(abs(F.modesFourier(:,:,i)))));
%     end
%     F.modesFourier = F.modesFourier ./ max(max(max(abs(F.modesFourier))));
    
    %% Superpixel encode
    F.patterns_SP.modes = encode_superpixel(F.modes,max_val);
    F.patterns_SP.modes_ref = encode_superpixel(F.modes_ref,max_val);
    F.patterns_SP.modes_half = encode_superpixel(F.modes_half,max_val);
    
    %% Phase Encoding
    % F.patterns_SP.modes = encode_phaseEncoding(F.modes);
    % F.patterns_SP.modes_ref = encode_phaseEncoding(F.modes_ref);
    % F.patterns_SP.modes_half = encode_phaseEncoding(F.modes_half);

    % F.patterns_SP.modesFourier = encode_superpixel(F.modesFourier);
    
    % Test Fourier domain modulation
    % modes_fourier = fftshift(fft2(F.modes));
    % modes_fourier_ref = fftshift(fft2(F.modes_ref));
    % % modes_fourier = modes_fourier/max(max(max(abs(modes_fourier))));
    % % modes_fourier_ref = modes_fourier_ref/max(max(max(abs(modes_fourier_ref))));
    % F.patterns_SP.modes = encode_superpixel(modes_fourier);
    % F.patterns_SP.modes_ref = encode_superpixel(modes_fourier_ref);


    F.pattern_width = size(F.patterns_SP.modes,1);
    F.pattern_height = size(F.patterns_SP.modes,2);

%     save(fName,'F');
end
end

