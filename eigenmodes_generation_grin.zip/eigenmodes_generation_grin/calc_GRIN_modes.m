function [modes_field, mode_info, n_modes, core_mask] = ...
    calc_GRIN_modes(r_core, n_core, NA, wavelength, ...
                    grid_size, r_plot_max, basis)
% CALC_GRIN_MODES
% 支持三种基底：
%   'LP'        - 实数 LP 模式              → double
%   'LP_complex'- 伪 complex LP（×exp(iπ/2)）→ complex double  ★ 新增
%   'OAM'       - 真复值 OAM 模式           → complex double

    %% 参数检查
    if nargin < 7 || isempty(basis)
        basis = 'LP';
    end
    basis = upper(basis);
    if ~ismember(basis, {'LP', 'LP_COMPLEX', 'OAM'})
        error('basis 必须是 ''LP'' / ''LP_complex'' / ''OAM''');
    end
    use_OAM        = strcmp(basis, 'OAM');
    use_LP_complex = strcmp(basis, 'LP_COMPLEX');                % ★ 新增

    %% 光纤参数（不变）
    k0 = 2 * pi / wavelength;
    V = k0 * r_core * NA;
    M = floor(V / 2);
    Delta = NA^2 / (2 * n_core^2);
    g = sqrt(2 * Delta) / r_core;
    r0 = 1 / sqrt(k0 * n_core * g);

    fprintf('===== GRIN 光纤参数 =====\n');
    fprintf('basis = %s\n', basis);
    fprintf('V = %.2f, M = %d, r0 = %.2f um\n', V, M, r0);

    %% 网格 + mask（不变）
    x = linspace(-r_plot_max, r_plot_max, grid_size);
    [X, Y] = meshgrid(x, x);
    R = sqrt(X.^2 + Y.^2);
    PHI = atan2(Y, X);
    rho = R / r0;
    rho2 = rho.^2;
    core_mask = (R <= r_core);

    %% 预分配
    N_total = M * (M + 1) / 2;
    if use_OAM || use_LP_complex                                  % ★ 修改
        modes_field = complex(zeros(grid_size, grid_size, N_total));
    else
        modes_field = zeros(grid_size, grid_size, N_total);
    end
    mode_info = struct('l', {}, 'p', {}, 'orient', {}, 'group', {});
    mode_idx = 0;

    %% ★ 新增：LP_complex 用的全局相位偏置
    if use_LP_complex
        global_phase = exp(1i * pi/2);   % 乘 i，相当于把实数转成纯虚数
    end

    %% 枚举所有模式
    for group = 0:(M - 1)
        for l = mod(group, 2):2:group
            p = (group - l) / 2 + 1;

            Lpl = gen_laguerre(p - 1, l, rho2);
            radial = (rho.^l) .* Lpl .* exp(-rho2 / 2);

            if l == 0
                mode_idx = mode_idx + 1;
                if use_OAM
                    field = complex(radial);
                elseif use_LP_complex
                    field = radial * global_phase;                % ★ 新增
                else
                    field = radial;
                end
                field(~core_mask) = 0;
                field = field / sqrt(sum(abs(field(:)).^2));
                modes_field(:,:,mode_idx) = field;
                mode_info(mode_idx).l = 0;
                mode_info(mode_idx).p = p;
                mode_info(mode_idx).orient = 'none';
                mode_info(mode_idx).group = group;

            else
                if use_OAM
                    % ----- 真 OAM 复值 -----
                    mode_idx = mode_idx + 1;
                    field = radial .* exp(+1i * l * PHI);
                    field(~core_mask) = 0;
                    field = field / sqrt(sum(abs(field(:)).^2));
                    modes_field(:,:,mode_idx) = field;
                    mode_info(mode_idx).l = +l;
                    mode_info(mode_idx).p = p;
                    mode_info(mode_idx).orient = '+l';
                    mode_info(mode_idx).group = group;

                    mode_idx = mode_idx + 1;
                    field = radial .* exp(-1i * l * PHI);
                    field(~core_mask) = 0;
                    field = field / sqrt(sum(abs(field(:)).^2));
                    modes_field(:,:,mode_idx) = field;
                    mode_info(mode_idx).l = -l;
                    mode_info(mode_idx).p = p;
                    mode_info(mode_idx).orient = '-l';
                    mode_info(mode_idx).group = group;

                else
                    % ----- 实数 LP 或 伪 complex LP -----
                    % cos
                    mode_idx = mode_idx + 1;
                    field = radial .* cos(l * PHI);
                    if use_LP_complex
                        field = field * global_phase;             % ★ 新增
                    end
                    field(~core_mask) = 0;
                    field = field / sqrt(sum(abs(field(:)).^2));
                    modes_field(:,:,mode_idx) = field;
                    mode_info(mode_idx).l = l;
                    mode_info(mode_idx).p = p;
                    mode_info(mode_idx).orient = 'cos';
                    mode_info(mode_idx).group = group;

                    % sin
                    mode_idx = mode_idx + 1;
                    field = radial .* sin(l * PHI);
                    if use_LP_complex
                        field = field * global_phase;             % ★ 新增
                    end
                    field(~core_mask) = 0;
                    field = field / sqrt(sum(abs(field(:)).^2));
                    modes_field(:,:,mode_idx) = field;
                    mode_info(mode_idx).l = l;
                    mode_info(mode_idx).p = p;
                    mode_info(mode_idx).orient = 'sin';
                    mode_info(mode_idx).group = group;
                end
            end
        end
    end

    n_modes = mode_idx;
    fprintf('实际生成模式数: %d\n', n_modes);
    fprintf('dtype: %s, isreal: %d\n', class(modes_field), isreal(modes_field));
end


function L = gen_laguerre(n, alpha, x)
    if n == 0
        L = ones(size(x));
    elseif n == 1
        L = 1 + alpha - x;
    else
        Lm1 = 1 + alpha - x;
        Lm2 = ones(size(x));
        for k = 1:(n - 1)
            L = ((2*k + 1 + alpha - x) .* Lm1 - (k + alpha) * Lm2) / (k + 1);
            Lm2 = Lm1;
            Lm1 = L;
        end
    end
end
