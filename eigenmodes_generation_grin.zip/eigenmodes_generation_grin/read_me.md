
# GRIN 多模光纤 LP 模式场生成工具

## 📌 简介

本工具用于解析生成**梯度折射率（GRIN）多模光纤**的全部 55 个 LP 模式场分布，
并提供按模式组三角形排列的可视化功能。生成的 `.mat` 文件可直接在 Python 中读取使用。

---

## 📁 文件结构

```text
.
├── calc_GRIN_modes.m             % 解析生成 LP 模式场（含纤芯 mask）
├── plot_modes_by_group.m         % 按模式组三角形排列显示（支持 subplot、强度/相位）
├── plot_modes.m                  % 按序号网格排列显示
├── main_generate_modes.m         % 主脚本：生成 → 显示 → 保存
└── mmf_55modes_GRIN_128_PD1.05.mat   % 输出文件
```

---

## 🔬 光纤参数

| 参数 | 符号 | 值 | 单位 |
|------|------|-----|------|
| 纤芯半径 | r_core | 25 | μm |
| 纤芯折射率 | n_core | 1.45 | — |
| 数值孔径 | NA | 0.2 | — |
| 工作波长 | λ | 1.568 | μm |
| 归一化频率 | V | ≈ 20.15 | — |
| 模式组数 | M | 10 | — |
| 模式总数 | N | 55 | — |
| 网格分辨率 | grid_size | 128 × 128 | px |
| 绘图区域比 | PD | 1.05 | — |

---

## 📐 模式场表达式

GRIN 光纤的 LP 模式场为：

```
E_{l,p}(r,φ) = (r/r₀)^l · L_{p-1}^{(l)}(r²/r₀²) · exp(-r²/2r₀²) × cos(lφ)  [a 模式]
                                                                     × sin(lφ)  [b 模式]
```

- `l` — 角向量子数（花瓣数）
- `p` — 径向量子数（同心环数）
- `r₀ = 1/√(k₀·n_core·g)` — 基模振荡长度
- `L_{p-1}^{(l)}` — 广义 Laguerre 多项式（递推计算，无需 Symbolic Math Toolbox）

---

## 🔢 模式排序规则

每个模式组 g 内部，l **从大到小**排列（高 l 在前），也可改为从小到大以匹配 OM2 标准：

**高 l 在前（默认）**：`for l = group:-2:0`

| 模式组 g | 模式排列 | 模式数 |
|:--------:|----------|:------:|
| 0 | LP₀₁ | 1 |
| 1 | LP₁₁ᵃ, LP₁₁ᵇ | 2 |
| 2 | LP₂₁ᵃ, LP₂₁ᵇ, LP₀₂ | 3 |
| 3 | LP₃₁ᵃ, LP₃₁ᵇ, LP₁₂ᵃ, LP₁₂ᵇ | 4 |
| … | … | … |
| **合计** | | **55** |

**低 l 在前（OM2 标准）**：`for l = mod(group,2):2:group`

| 模式组 g | 模式排列 | 模式数 |
|:--------:|----------|:------:|
| 0 | LP₀₁ | 1 |
| 1 | LP₁₁ᵃ, LP₁₁ᵇ | 2 |
| 2 | LP₀₂, LP₂₁ᵃ, LP₂₁ᵇ | 3 |
| 3 | LP₁₂ᵃ, LP₁₂ᵇ, LP₃₁ᵃ, LP₃₁ᵇ | 4 |
| … | … | … |
| **合计** | | **55** |

> 切换排序只需修改 `calc_GRIN_modes.m` 中的一行循环。

---

## 🎭 纤芯 Mask

生成时对所有模式施加圆形纤芯 mask（`R <= r_core`），确保纤芯外场值严格为零。
mask 在归一化**之前**施加：

```matlab
field(~core_mask) = 0;                          % 先截断
field = field / sqrt(sum(abs(field(:)).^2));     % 再归一化
```

---

## 🚀 MATLAB 快速开始

### 生成模式

```matlab
grid_size  = 128;
r_core     = 25;
n_core     = 1.45;
NA         = 0.2;
wavelength = 1.568;
PD         = 1.05;
[modes_field, mode_info, n_modes] = ... calc_GRIN_modes(r_core, n_core, NA, wavelength, ... grid_size, PD * r_core);
```


### 显示模式（强度 + 相位，subplot）

```matlab
fig = figure('Color', 'k', 'Position', [50 50 1800 900]);
ax1 = subplot(1, 2, 1); plot_modes_by_group(modes_field, ax1, 'intensity'); title(ax1, 'Intensity', 'Color', 'w', 'FontSize', 14);
ax2 = subplot(1, 2, 2); plot_modes_by_group(modes_field, ax2, 'phase'); title(ax2, 'Phase', 'Color', 'w', 'FontSize', 14);
```


### 保存

```matlab
save('mmf_55modes_GRIN_128_PD1.05.mat', ...
     'modes_field', 'mode_info', 'n_modes');
exportgraphics(fig, 'LP_modes_triangle.pdf', ... 'ContentType', 'vector', 'Resolution', 600);
```


---

## 🖼️ 显示函数说明

### `plot_modes_by_group(modes_field, ax, type)`

按模式组三角形排列显示，每行一个模式组。

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `modes_field` | (H, W, N) 模式场数据 | 必填 |
| `ax` | 目标 axes（用于 subplot），传 `[]` 则新建 figure | `[]` |
| `type` | `'intensity'`（hot colormap）或 `'phase'`（hsv，±π） | `'intensity'` |

### `plot_modes(modes_field, N, ax, type)`

按序号网格排列显示前 N 个模式。参数同上。

### subplot 用法示例

```matlab
fig = figure('Color', 'k', 'Position', [50 50 1800 1400]);
ax1 = subplot(2, 2, 1); plot_modes_by_group(modes_field, ax1, 'intensity'); title(ax1, 'GRIN Intensity', 'Color', 'w');
ax2 = subplot(2, 2, 2); plot_modes_by_group(modes_field, ax2, 'phase'); title(ax2, 'GRIN Phase', 'Color', 'w');
ax3 = subplot(2, 2, 3); plot_modes(modes_field, 55, ax3, 'intensity'); title(ax3, 'Grid View', 'Color', 'w');
```


---

## 📦 输出文件格式

`mmf_55modes_GRIN_128_PD1.05.mat` 包含：

| 变量名 | 尺寸 | 类型 | 说明 |
|--------|------|------|------|
| `modes_field` | (128, 128, 55) | double | LP 模式场（实数，纤芯外为 0） |
| `mode_info` | 1×55 struct | struct | 每个模式的 (l, p, orient, group) |
| `n_modes` | 1×1 | double | 模式总数 = 55 |

`mode_info` 结构体字段：

| 字段 | 类型 | 示例 | 说明 |
|------|------|------|------|
| `l` | int | 2 | 角向量子数 |
| `p` | int | 1 | 径向量子数 |
| `orient` | string | `'cos'` / `'sin'` / `'none'` | 方位取向（l=0 时为 none） |
| `group` | int | 2 | 所属模式组编号 |

---

## 🐍 Python 调用

### 读取 .mat 文件

```python
import scipy.io as sio
import numpy as np
data = sio.loadmat('mmf_55modes_GRIN_128_PD1.05.mat') modes_field = data['modes_field'] # (128, 128, 55) MATLAB 格式 modes_field = np.transpose(modes_field, (2, 0, 1)) # (55, 128, 128) Python 格式 (N, H, W)
print(f'Shape: {modes_field.shape}') # (55, 128, 128) print(f'Dtype: {modes_field.dtype}') # float64 print(f'Range: {modes_field.min():.4f} ~ {modes_field.max():.4f}')
```


> **注意**：转置使用 `(2, 0, 1)` 而非 `(2, 1, 0)`，否则图像会被翻转。

### 如果 scipy 报错（v7.3 格式）

```python
import h5py
import numpy as np
f = h5py.File('mmf_55modes_GRIN_128_PD1.05.mat', 'r') modes_field = np.array(f['modes_field']) # h5py 维度是转置的 modes_field = modes_field.transpose(2, 1, 0) # 转回 (N, H, W) f.close()
```


### 转为 PyTorch Tensor

```python
import torch
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') mmf_modes = torch.tensor(modes_field, dtype=torch.complex64, device=device) print(f'Tensor shape: {mmf_modes.shape}') # torch.Size([55, 128, 128])
```


### 显示单个模式

```python
import matplotlib.pyplot as plt
mode_idx = 0 # LP₀₁ img = np.abs(modes_field[mode_idx])**2 img = img / img.max()
plt.figure(figsize=(4, 4), facecolor='k') plt.imshow(img, cmap='hot') plt.axis('off') plt.title(f'Mode {mode_idx+1}', color='w') plt.show()
```


### 显示全部 55 个模式（网格排列）

```python
N = 55
n_cols = 8
n_rows = int(np.ceil(N / n_cols))
fig, axes = plt.subplots(n_rows, n_cols, figsize=(16, 14), facecolor='k')
for i in range(n_rows * n_cols): ax = axes[i // n_cols, i % n_cols] if i < N: img = np.abs(modes_field[i])**2 img = img / img.max() ax.imshow(img, cmap='hot') ax.set_title(f'{i+1}', color='w', fontsize=7) ax.axis('off') ax.set_facecolor('k')
plt.tight_layout() plt.savefig('modes_55_grid.png', dpi=300, bbox_inches='tight', facecolor='k') plt.show()
```


### 显示强度 + 相位对比

```python
mode_idx = 10  # 选一个有花瓣的模式
fig, axes = plt.subplots(1, 2, figsize=(8, 4), facecolor='k')
强度
img_int = np.abs(modes_field[mode_idx])**2 img_int = img_int / img_int.max() axes[0].imshow(img_int, cmap='hot') axes[0].set_title('Intensity', color='w') axes[0].axis('off')
相位（纤芯外用 mask 隐藏）
img_phase = np.angle(modes_field[mode_idx]) mask = np.abs(modes_field[mode_idx]) > 1e-6 img_phase_masked = np.where(mask, img_phase, np.nan) axes[1].imshow(img_phase_masked, cmap='hsv', vmin=-np.pi, vmax=np.pi) axes[1].set_title('Phase', color='w') axes[1].axis('off')
plt.tight_layout() plt.show()
```


### 叠加生成散斑图

```python
# 随机生成复数权重
N = 55
a = np.random.rand(N)
a = a / np.linalg.norm(a)                      # L2 归一化
phi = np.random.uniform(-np.pi, np.pi, N)
phi[0] = 0                                      # 第一个模式相位固定为 0
k = a * np.exp(1j * phi)                        # 复数权重
叠加
E = np.sum(k[:, None, None] * modes_field, axis=0) # (128, 128) complex I = np.abs(E)**2 # 强度 amp = np.abs(E) # 振幅
fig, axes = plt.subplots(1, 2, figsize=(8, 4), facecolor='k') axes[0].imshow(I / I.max(), cmap='hot') axes[0].set_title('Intensity |E|²', color='w') axes[0].axis('off') axes[1].imshow(amp / amp.max(), cmap='hot') axes[1].set_title('Amplitude |E|', color='w') axes[1].axis('off') plt.tight_layout() plt.show()
```


---

## ⚙️ 可调参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `grid_size` | 128 | 网格分辨率，越大越精细（推荐 128 训练，256 论文图） |
| `PD` | 1.05 | 绘图区域 / 纤芯半径比，越小模式越大 |
| `r_core` | 25 μm | 纤芯半径 |
| `n_core` | 1.45 | 纤芯折射率 |
| `NA` | 0.2 | 数值孔径，决定模式数 |
| `wavelength` | 1.568 μm | 工作波长 |

改变 NA 或 r_core 会改变模式总数 N = M(M+1)/2，其中 M = floor(V/2)。

---

## 📝 注意事项

1. **模式为实数**：GRIN LP 模式由 cos(lφ) / sin(lφ) 构成，场值为实数。相位图只有 0 和 π 两个值（红/青二值），这是正确的
2. **纤芯 Mask**：纤芯外场值严格为 0，相位图中纤芯外不显示
3. **功率归一化**：每个模式满足 Σ|E_i|² = 1（所有像素求和）
4. **Python 维度**：MATLAB 存储为 (H, W, N)，Python 中需转为 (N, H, W)
5. **排序可切换**：修改 `calc_GRIN_modes.m` 中 `for l = ...` 一行即可切换高l/低l在前
