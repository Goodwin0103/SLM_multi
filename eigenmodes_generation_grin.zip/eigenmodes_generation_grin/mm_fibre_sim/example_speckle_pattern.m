% -------------------------------------------------------------------------
% example_speckle_pattern
% Fibre Optic LP Mode Solver and Simulator
% For Release 2 June 2020
% ------------------------------------------------------------------------
% Michael Hughes   m.r.hughes@kent.ac.uk
% Applied Optics Group, University of Kent
%
% License: BSD [https://opensource.org/licenses/BSD-3-Clause]
% -------------------------------------------------------------------------
% Demonstrates simulation of a speckle pattern produce by multimode fibre.
% A fibre is modelled, and a random input field is injected into the fibre.
% This is coupled into each mode, propagated along the fibre, and the 
% field and intensity recovered at the far end by summing the modes.
% -------------------------------------------------------------------------

clear
addpath('lib');

% Define the fibre characteristics and wavelength
nCore = 1.46;
nCladding = 1.42;
wavelength = 0.5;    % microns
coreRadius = 10;     % microns
fibreLength = 1000; % microns

na = fibre_na(nCore, nCladding);
fprintf('Estimating %d LP modes from V number. \n', round(est_num_modes(wavelength, coreRadius, nCore, nCladding) /2));

% Define the plot area
maxPlotRadius = coreRadius * 1.2;  % Lets us see the power in the cladding
gridSize = 200;                    % pixels

% Find all the LP modes
[modes, nModes] = find_LP_modes(coreRadius, nCore, nCladding, wavelength);

% Report how many modes are found
fprintf('Estimating %d LP modes from V number. \n', round(est_num_modes(wavelength, coreRadius, nCore, nCladding) /2));
fprintf('Found %d LP modes (%d including rotations). \n', length(modes), nModes);

% Calculate the 2D field amplitudes of the LP modes
[modeSin, modeCos] = plot_all_LP_modes(modes, coreRadius, maxPlotRadius, gridSize);

% Random amplitude and phase in each mode orientation
modeCouplingSin = rand(length(modes),1) + 1i * rand(length(modes),1);
modeCouplingCos = rand(length(modes),1) + 1i * rand(length(modes),1);
[endField, endIntensity, endModeCouplingSin, endModeCouplingCos] = propagate_through_fibre(modeSin, modeCos, modeCouplingSin, modeCouplingCos, [modes.beta], 1, fibreLength);

% Plot intensity, ampltidue and phase
figure(1); title('Speckle pattern intensity');
imagesc(endIntensity); colormap('gray'); title('Intensity');

figure(2); title('Speckle pattern amplitude');
imagesc(abs(endField)); colormap('gray'); title('Amplitude');

figure(3); title 'Speckle pattern phase');
imagesc(angle(endField)); colormap('hsv'); title('Phase');
