function plot_modes(modes_field, N, ax, type)
% PLOT_MODES 显示前 N 个模式
%
% 用法:
%   plot_modes(modes_field, 55)                    % 独立figure，强度
%   plot_modes(modes_field, 55, ax)                % 指定axes，强度
%   plot_modes(modes_field, 55, ax, 'intensity')   % 强度
%   plot_modes(modes_field, 55, ax, 'phase')       % 相位
%
% 输入:
%   modes_field - [N_total, H, W] 或 [H, W, N_total]
%   N           - 要显示的模式数
%   ax          - (可选) 目标 axes
%   type        - (可选) 'intensity' 或 'phase'，默认 'intensity'

    if nargin < 4
        type = 'intensity';
    end
    if nargin < 3 || isempty(ax)
        figure('Color', 'w', ...
               'Position', [100 100 800 700]);
        ax = gca;
    end

    % 自动判断维度格式
    sz = size(modes_field);
    if sz(1) < sz(2) && sz(1) < sz(3)
        modes_field = permute(modes_field, [2, 3, 1]);
    end

    N_total = size(modes_field, 3);
    N = min(N, N_total);

    n_cols = ceil(sqrt(N));
    n_rows = ceil(N / n_cols);

    axes(ax);
    draw_mosaic(modes_field, N, n_rows, n_cols, type);
end


function draw_mosaic(modes_field, N, n_rows, n_cols, type)
    [H, W, ~] = size(modes_field);
    pad = 2;

    canvas = NaN(n_rows*(H+pad)+pad, ...
                 n_cols*(W+pad)+pad);

    for idx = 1:N
        row = floor((idx-1) / n_cols);
        col = mod(idx-1, n_cols);

        r1 = row*(H+pad) + pad + 1;
        c1 = col*(W+pad) + pad + 1;

        field = modes_field(:,:,idx);

        switch type
            case 'intensity'
                img = abs(field).^2;
                if max(img(:)) > 0
                    img = img / max(img(:));
                end
            case 'phase'
                img = angle(field);
        end

        canvas(r1:r1+H-1, c1:c1+W-1) = img;
    end

    imagesc(canvas);
    axis image off;

    switch type
        case 'intensity'
            colormap(gca, hot);
        case 'phase'
            colormap(gca, hsv);
            caxis([-pi, pi]);
            cb = colorbar;
            cb.Ticks = [-pi, 0, pi];
            cb.TickLabels = {'-\pi', '0', '\pi'};
    end

    % 序号标签
    label_color = 'w';
    for idx = 1:N
        row = floor((idx-1) / n_cols);
        col = mod(idx-1, n_cols);
        c_center = col*(W+pad) + pad + W/2;
        r_top = row*(H+pad) + pad - 1;
        text(c_center, r_top, sprintf('%d', idx), ...
            'HorizontalAlignment', 'center', ...
            'VerticalAlignment', 'bottom', ...
            'FontSize', 6, 'Color', label_color, ...
            'FontWeight', 'bold');
    end
end
