grid_size = 50;
show_Plots = 0;
current_path = pwd;
save_folder = fullfile(current_path, 'mmf_data');
PD_factor = 1.0;
fiber_type = 'GRIN';

%Fiber Parameters 55modes
F.NA = 0.2;
F.r_core = 25;          % um
F.wavelength = 1.550;   % um
F.n_core = 1.45;
% 
%F.NA = 0.1;
%F.r_core = 10;          % um
%F.wavelength = 0.650;   % um
%F.n_core = 1.2;

% ★ 新增：选择模式基底
basis = 'LP_complex';   % 'LP' 'LP_complex' 或 'OAM'

%% 生成模式
[modes_field, mode_info, n_modes] = calc_GRIN_modes( ...
    F.r_core, F.n_core, F.NA, F.wavelength, ...
    grid_size, PD_factor * F.r_core, basis);

%% 保存
filename = sprintf('mmf_%dmodes_%s_%s_%d_PD%.2f_r%d.mat', ...
                   n_modes, fiber_type, basis, ...
                   grid_size, PD_factor, F.r_core);
full_path = fullfile(save_folder, filename);

if ~exist(save_folder, 'dir')
    mkdir(save_folder);
end
save(full_path, 'modes_field', 'mode_info', 'n_modes', 'basis', 'F');
fprintf('已保存：%s\n', full_path);

%% 可视化（强度 + 相位）
if show_Plots
    figure('Color', 'k', 'Position', [50 50 1800 900]);
    ax1 = subplot(1, 2, 1);
    plot_modes_by_group(modes_field, ax1, 'intensity');
    title(ax1, ['Intensity (' basis ')'], 'Color', 'w', 'FontSize', 14);

    ax2 = subplot(1, 2, 2);
    plot_modes_by_group(modes_field, ax2, 'phase');
    title(ax2, ['Phase (' basis ')'], 'Color', 'w', 'FontSize', 14);
end
