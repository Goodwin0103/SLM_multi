grid_size = 128;
show_Plots = 1;
current_path = pwd;
save_folder = fullfile(current_path, 'mmf_data');
PD_factor = 1.05;
fiber_type = 'GRIN';

% Fiber Parameters 55modes
F.NA = 0.2;
F.r_core = 25;          % um
F.wavelength = 1.550;   % um
F.n_core = 1.45;
% 
%%
[modes_field, mode_info, n_modes] = ...
    calc_GRIN_modes(F.r_core, F.n_core, F.NA, F.wavelength, grid_size, PD_factor*F.r_core);
% Display images
plot_modes_by_group(modes_field,[], 'intensity');
%%
filename = sprintf('mmf_%dmodes_%s_%d_PD%.2f_%d.mat', ...
                   n_modes, fiber_type, grid_size, PD_factor, F.r_core);

full_path = fullfile(save_folder, filename);

if ~exist(save_folder, 'dir')
    mkdir(save_folder);
end

save(full_path, 'modes_field', 'mode_info', 'n_modes');

% 
% save('mmf_55modes_GRIN_128_PD1.05.mat', ...
%      'modes_field', 'mode_info', 'n_modes');

%%
fig1 = figure('Color', 'k', 'Position', [50 50 1800 900]);

ax1 = subplot(1, 2, 1);
plot_modes_by_group(modes_field, ax1, 'intensity');
title(ax1, 'm', 'Color', 'w', 'FontSize', 14);

ax2 = subplot(1, 2, 2);
plot_modes_by_group(modes_field, ax2, 'phase');
title(ax2, 'p', 'Color', 'w', 'FontSize', 14);