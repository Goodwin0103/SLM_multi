function plot_modes_by_group(modes_field, ax, type)
% PLOT_MODES_BY_GROUP 按模式组三角形排列显示
%
% 用法:
%   plot_modes_by_group(modes_field)                        % 独立figure，强度
%   plot_modes_by_group(modes_field, ax)                    % 指定axes，强度
%   plot_modes_by_group(modes_field, ax, 'intensity')       % 强度
%   plot_modes_by_group(modes_field, ax, 'phase')           % 相位
%   plot_modes_by_group(modes_field, [], 'phase')           % 独立figure，相位

    if nargin < 3
        type = 'intensity';
    end
    if nargin < 2 || isempty(ax)
        figure('Color', 'k', ...
               'Position', [100 100 900 900]);
        ax = gca;
    end

    % 自动判断维度
    sz = size(modes_field);
    if sz(1) < sz(2) && sz(1) < sz(3)
        modes_field = permute(modes_field, [2, 3, 1]);
    end

    [H, W, N_total] = size(modes_field);

    % 自动判断模式组数: N = M(M+1)/2
    M = round((-1 + sqrt(1 + 8*N_total)) / 2);

    % 生成 LP 标签
    labels = generate_LP_labels(M);

    pad = 4;
    cell_h = H + pad;
    cell_w = W + pad;

    % 画布大小
    canvas_h = M * cell_h + pad;
    canvas_w = M * cell_w + pad;
    canvas = zeros(canvas_h, canvas_w);  % 黑色背景

    % 记录每个模式的位置（用于标签）
    positions = zeros(N_total, 2);  % [col_center, row_center]

    mode_idx = 0;
    for g = 0:(M - 1)
        n_in_group = g + 1;
        total_width = n_in_group * cell_w;
        offset_x = round((canvas_w - total_width) / 2);

        for k = 1:n_in_group
            mode_idx = mode_idx + 1;
            if mode_idx > N_total
                break;
            end

            field = modes_field(:,:,mode_idx);

            switch type
                case 'intensity'
                    img = abs(field).^2;
                    if max(img(:)) > 0
                        img = img / max(img(:));
                    end
                % 在 draw_triangle 函数里，把 phase 部分改成：
                case 'phase'
                    img = angle(field);

            end

            r1 = g * cell_h + pad + 1;
            r2 = r1 + H - 1;
            c1 = offset_x + (k-1) * cell_w + 1;
            c2 = c1 + W - 1;

            canvas(r1:r2, c1:c2) = img;
            positions(mode_idx,:) = ...
                [(c1+c2)/2, (r1+r2)/2];
        end
    end

    % 画到指定 axes
    axes(ax);

    switch type
        case 'intensity'
            imagesc(ax, canvas);
            colormap(ax, hot);
        case 'phase'
            imagesc(ax, canvas, [-pi, pi]);
            colormap(ax, hsv);
            cb = colorbar(ax);
            cb.Ticks = [-pi, 0, pi];
            cb.TickLabels = {'-\pi', '0', '\pi'};
            cb.Color = 'w';
    end

    axis(ax, 'image');
    axis(ax, 'off');
    set(ax, 'Color', 'k');

    % LP 模式标签（图片下方）
    mode_idx = 0;
    for g = 0:(M - 1)
        n_in_group = g + 1;
        total_width = n_in_group * cell_w;
        offset_x = round((canvas_w - total_width) / 2);

        for k = 1:n_in_group
            mode_idx = mode_idx + 1;
            if mode_idx > length(labels)
                break;
            end

            c_center = offset_x + (k-1)*cell_w + W/2;
            r_bottom = g * cell_h + pad + H + 3;

            text(ax, c_center, r_bottom, ...
                labels{mode_idx}, ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'top', ...
                'FontSize', 5, 'Color', 'w', ...
                'FontWeight', 'bold', ...
                'Interpreter', 'tex');
        end

        % 左侧模式组号
        row_center = g * cell_h + pad + H/2;
        text(ax, offset_x - 10, row_center, ...
            sprintf('g=%d', g), ...
            'HorizontalAlignment', 'right', ...
            'VerticalAlignment', 'middle', ...
            'FontSize', 7, 'Color', 'w');
    end
end


function labels = generate_LP_labels(M)
    labels = {};
    for g = 0:(M - 1)
        for l = g:-2:0
            p = (g - l) / 2 + 1;
            if l == 0
                labels{end+1} = ...
                    sprintf('LP_{%d,%d}', l, p);
            else
                labels{end+1} = ...
                    sprintf('LP_{%d,%d}^a', l, p);
                labels{end+1} = ...
                    sprintf('LP_{%d,%d}^b', l, p);
            end
        end
    end
end
