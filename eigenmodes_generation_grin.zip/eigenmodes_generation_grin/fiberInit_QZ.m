function F = fiberInit_QZ(grid_size, plot_scale, r_core, NA, wavelength)
%FIBERINIT Summary of this function goes here
%   Detailed explanation goes here

show_Plots = 1;

%% Fiber Parameters
F.plot_scale = 1.1;
F.NA = 0.1;
F.r_core = 12.5;
F.wavelength = 1.550;

switch nargin
    case 2
        F.plot_scale = plot_scale;
%     case 3
%         F.NA = NA;
%         F.r_core = r_core;
    case 4
        F.NA = NA;
        F.r_core = r_core;
    case 5
        F.NA = NA;
        F.r_core = r_core;
        F.wavelength = wavelength;     % 
    % otherwise
        % F.NA = 0.1; %0.1
        % F.r_core = 12.5; %+/- 1.5m  12.5             % 3, 4, 5, 12.5
        % F.wavelength = 0.532;     % 
        % F.plot_scale = 1.1;
end

F.n_core = 1.4585;
F.n_core = 1.4607;

F.n_cladding = sqrt(F.n_core^2-F.NA^2);    % sqrt(n_core^2-NA^2)


addpath(genpath('mm_fibre_sim'));

%% Plot Area
F.r_plot_max = F.plot_scale*F.r_core;    %1.3 warum berhaupt?

%% Check load data
fName = ['Fiber_',...
    num2str(F.r_core*1000),'nm_core_',...
    num2str(F.NA*1000),'m_NA_',...
    num2str(grid_size),'gridSize'];

if isfile([fName,'.mat'])
    load([fName,'.mat'],'F');
else
    %% Calc Fiber
    [F.modeSolver,F.modes,F.n_modes, F.beta_sorted_indices,F.mode_betas] = calc_Modes(F, grid_size, show_Plots);  % Modes for SLM
            
    % Gaussian reference, superposition
    F.modes_ref = (1/sqrt(2)) .* ( F.modes(:,:,1)+F.modes );
    F.modes_half= (1/sqrt(2)) .* F.modes;
    % F.modes_ref  = 0.5*F.modes(:,:,1) + 0.5*F.modes;
    % F.modes_half = 0.5*F.modes;
    max_val = max([ ...
        abs(F.modes), ...
        abs(F.modes_ref), ...
        abs(F.modes_half)],[],'all');

  
end
end

