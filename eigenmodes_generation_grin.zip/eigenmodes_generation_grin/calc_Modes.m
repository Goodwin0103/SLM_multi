function [modes,modes_complex, nr_of_modes, beta_sorted_indices,mode_betas_all] = calc_Modes(fiber,size_grid,show_Plots)
%CALC_MODES Summary of this function goes here
%   Detailed explanation goes here

%% Finding all LP-Modes
[modes, n_modes] = find_LP_modes(fiber.r_core, fiber.n_core, fiber.n_cladding, fiber.wavelength);
% nr_of_modes = length(modes);

% fprintf('Estimating %d LP modes from V number. \n',...
%     round(est_num_modes(fiber.wavelength, fiber.r_core, fiber.n_core, fiber.n_cladding) /2));
% fprintf('Found %d LP modes (%d including rotations). \n', length(modes), n_modes);

%% Calculate Amplitudes
[modeSin, modeCos] = plot_all_LP_modes(modes, fiber.r_core, fiber.r_plot_max, size_grid);

modes_all = zeros(size(modeSin,1),size(modeSin,2),2*size(modeSin,3));
modes_all(:,:,1:2:end) = modeSin;
modes_all(:,:,2:2:end) = modeCos;   % include Rotations

% figure(42);   % empty modes included
% for i=1:size(modes_all,3)
%     subplot(size(modes_all,3),1,i);
%     imagesc(squeeze(modes_all(:,:,i)));
%     pbaspect([1 1 1]);
% end

modes_indices = squeeze(cell2mat(struct2cell(modes)))';
mode_betas = modes_indices(:,4);
mode_betas_all = zeros(1,2*size(modeSin,3));
mode_betas_all(:,1:2:end) = mode_betas;
mode_betas_all(:,2:2:end) = mode_betas;

layer_not_empty = any(any(modes_all));
modes_all = modes_all(:,:,layer_not_empty); % delete empty rotations
nr_of_modes = size(modes_all,3);

mode_betas_all = mode_betas_all(:,layer_not_empty);

[mode_betas_all,beta_sorted_indices]=sort(mode_betas_all,'descend');
modes_all = modes_all(:,:,beta_sorted_indices);

%% OAM
doOAM = false;
if doOAM
    modes_oam = zeros(size(modes_all));
    i=1;
    while i<nr_of_modes
        currentBeta = mode_betas_all(i);
        nextBeta = mode_betas_all(i+1);
        if nextBeta == currentBeta
            modes_oam(:,:,i) = 1/sqrt(2)*modes_all(:,:,i) + 1/sqrt(2)*exp(1i*2*pi*0.25) .* modes_all(:,:,i+1);
            modes_oam(:,:,i+1) = 1/sqrt(2)*modes_all(:,:,i) + 1/sqrt(2)*exp(-1i*2*pi*0.25) .* modes_all(:,:,i+1);
            i = i + 2;
        else
            modes_oam(:,:,i) = modes_all(:,:,i);
            i = i + 1;
        end
    end
    modes_all = modes_oam;
end
        


% if show_Plots==1
%     figure(41);
%     title('Available Modes');
%     for i=1:size(modes_all,3)
%         subplot(size(modes_all,3),1,i);
%         imagesc(squeeze(modes_all(:,:,i)));
%         pbaspect([1 1 1]);
%         colorbar;
%     end
% end

%% Calculate Complex Modes
modes_complex = modes_all;
modes_complex = modes_complex.*exp(1i*pi/2);
% modes_complex(sign(real(modes_all))>0) = modes_complex(sign(real(modes_all))>0).*exp(1i*pi/2);
% modes_complex(sign(real(modes_all))<=0) = modes_complex(sign(real(modes_all))<=0).*exp(1i*pi/2);

for i=1:size(modes_complex,3)
    modes_complex(:,:,i) = modes_complex(:,:,i)./sum(sum(abs(modes_complex(:,:,i))));    % power = 1
end


%% Norm
% mode_maxima = max(max(max(abs(modes_complex).^2)));

%mode_maxima = max(max(max(abs(modes_complex).^2)));
%modes_complex = modes_complex./mode_maxima;


% modes_complex = modes_complex ./ sum(sum(abs(modes_complex(:,:,1).^2)));

%% Viz
if show_Plots==1
    show_Phase=1;
    if show_Phase
        figure(41);tiledlayout('flow');
        title('Available Modes');
        % n_plot_rows = floor(sqrt(2*nr_of_modes));
        % n_plot_cols = ceil((2*nr_of_modes)/n_plot_rows);
        for i=0:nr_of_modes-1
            nexttile;%subplot(n_plot_rows,n_plot_cols,2*i+1);
            imagesc(abs(squeeze(modes_complex(:,:,i+1))).^2);  pbaspect([1 1 1]);   %colorbar;
            nexttile;%subplot(n_plot_rows,n_plot_cols,2*i+2);
            imagesc(angle(squeeze(modes_complex(:,:,i+1))));  pbaspect([1 1 1]);   %colorbar;
        end
    else
        figure(411);tiledlayout('flow');
        title('Available Modes');
        % n_plot_rows = floor(sqrt(2*nr_of_modes));
        % n_plot_cols = ceil((2*nr_of_modes)/n_plot_rows);
        for i=0:nr_of_modes-1
            nexttile;%subplot(n_plot_rows,n_plot_cols,i+1);
            imagesc(abs(squeeze(modes_complex(:,:,i+1))).^2);  pbaspect([1 1 1]);  %colorbar;
            % nexttile;%subplot(n_plot_rows,n_plot_cols,2*i+2);
            % imagesc(angle(squeeze(modes_complex(:,:,i+1))));  pbaspect([1 1 1]);   %colorbar;
        end
    end

%     figure(421);
%     plot(squeeze(max(max(abs(modes_complex)))));title('Max Brightness in Modes');
% 
%     figure(43);
%     plot(mode_betas_all);title('Modes beta');
% 
%     figure(44);
%     power_modes = zeros(nr_of_modes,1);
%     for i=1:nr_of_modes
%         power_modes(i) = sum(sum(modes_complex(:,:,i).*conj(modes_complex(:,:,i))));
%     end
%     plot(power_modes);title('Power of Modes');
end

end


